import React, { useState } from 'react'
import { useDispatch,useSelector } from 'react-redux'
import { login } from './Redux/Splices/User'

function Login() {
    const dispatch=useDispatch()
    // const selector = useSelector();
    const [name,setName]=useState('')
    // const user=useSelector(state=>state.user.value)
    return (
        <form>
            <label>Name : </label>
            <input type='text' value={name} onChange={e=>setName(e.target.value)}/>
            <button onClick={()=>dispatch(login())}> OK</button>
        </form>
    )
}

export default Login
