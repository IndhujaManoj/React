
import './App.css';
import Login from './Login';
import Profile from './Profile';

function App() {
  return (
    <div className="App">
     <Login/>
     <Profile/>
    </div>
  );
}

export default App;
